# Nexus Select — Bot de vendas Discord

## Recursos
- `/loja`: publica o catálogo com botões de compra.
- `/produto-adicionar`: cadastra produto e estoque.
- `/estoque`: consulta estoque.
- `/pedido-pago`: confirma manualmente um pedido e baixa o estoque.
- `/pedido-cancelar`: cancela um pedido pendente.
- `/pedidos`: lista pedidos recentes.
- Cada compra abre um canal privado para o cliente e a equipe.
- Os dados ficam no arquivo `data.sqlite`.

## Requisitos
- Node.js 20 ou superior
- Um bot criado no Discord Developer Portal
- Permissões no servidor para criar canais e enviar mensagens

## Instalação no Windows
1. Instale Node.js LTS: https://nodejs.org/
2. Extraia o ZIP para uma pasta, por exemplo `C:\NexusSelectBot`.
3. Abra essa pasta no Explorador de Arquivos.
4. Na barra de endereço da pasta, digite `cmd` e pressione Enter.
5. Execute: `npm install`
6. Renomeie `.env.example` para `.env` e preencha as configurações.
7. Execute: `npm start`

## Criar e configurar o bot
1. Acesse https://discord.com/developers/applications e crie uma aplicação.
2. Em **Bot**, crie o bot e copie o token para `DISCORD_TOKEN` no `.env`.
3. Em **General Information**, copie o Application ID para `CLIENT_ID`.
4. Ative **Server Members Intent** se necessário no portal; este projeto não depende dele.
5. Em **OAuth2 > URL Generator**, marque `bot` e `applications.commands`.
6. Permissões recomendadas: View Channels, Send Messages, Embed Links, Read Message History, Manage Channels.
7. Abra o link gerado e adicione o bot ao seu servidor.
8. No Discord, ative o Modo Desenvolvedor em Configurações > Avançado.
9. Copie o ID do servidor para `GUILD_ID` e o ID do cargo da equipe para `ADMIN_ROLE_ID`.
10. Configure sua chave Pix e nome em `.env`. Não use chave de terceiros sem autorização.

## Como vender
1. Inicie o bot com `npm start`.
2. No Discord, use `/produto-adicionar` para cadastrar cada item e sua quantidade.
3. Use `/loja` no canal em que deseja publicar o catálogo.
4. Quando um cliente clicar em Comprar, será criado um canal privado do pedido.
5. O cliente faz o Pix e envia o comprovante no canal privado.
6. A equipe confere o pagamento no aplicativo bancário e usa `/pedido-pago pedido_id`.
7. O bot confirma o pedido e reduz o estoque. **Nunca confirme pagamento só porque o cliente enviou uma imagem.**

## Importante sobre pagamentos
Esta versão NÃO verifica o Pix automaticamente. A equipe precisa conferir o recebimento real no banco e confirmar com `/pedido-pago`. Para confirmação automática, é necessário integrar um provedor de pagamento com API e webhook seguros.

## Segurança e limitações
- Nunca compartilhe o token do bot ou o arquivo `.env`.
- Não coloque senhas, tokens ou chaves privadas em mensagens públicas.
- Mantenha uma cópia de segurança de `data.sqlite`.
- O computador precisa permanecer ligado e conectado à internet para o bot ficar online.
- Venda somente produtos que você tenha autorização para comercializar e respeite as regras dos jogos e do Discord.
