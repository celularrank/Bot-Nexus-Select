require("dotenv").config();

const {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits
} = require("discord.js");
const Database = require("better-sqlite3");

const required = ["DISCORD_TOKEN", "CLIENT_ID", "GUILD_ID", "ADMIN_ROLE_ID"];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Falta configurar ${key} no arquivo .env`);
    process.exit(1);
  }
}

const db = new Database("data.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    price_cents INTEGER NOT NULL CHECK(price_cents >= 0),
    stock INTEGER NOT NULL CHECK(stock >= 0),
    active INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    channel_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    product_id INTEGER NOT NULL,
    product_name TEXT NOT NULL,
    price_cents INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT
  );
`);

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const money = cents => (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const parsePrice = value => {
  const normalized = String(value).trim().replace(/\./g, "").replace(",", ".");
  const number = Number(normalized);
  if (!Number.isFinite(number) || number < 0 || number > 1000000) return null;
  return Math.round(number * 100);
};
const isAdmin = interaction =>
  interaction.memberPermissions?.has(PermissionFlagsBits.Administrator) ||
  interaction.member?.roles?.cache?.has(process.env.ADMIN_ROLE_ID);

const commands = [
  new SlashCommandBuilder()
    .setName("loja")
    .setDescription("Publica o catálogo de produtos da Nexus Select"),
  new SlashCommandBuilder()
    .setName("produto-adicionar")
    .setDescription("Cadastra um produto ou adiciona estoque")
    .addStringOption(o => o.setName("nome").setDescription("Nome do produto").setRequired(true).setMaxLength(80))
    .addStringOption(o => o.setName("categoria").setDescription("Categoria do produto").setRequired(true)
      .addChoices(
        { name: "Contas LVL MAX", value: "Contas LVL MAX" },
        { name: "Frutas míticas e lendárias", value: "Frutas míticas e lendárias" }
      ))
    .addStringOption(o => o.setName("preco").setDescription("Preço, exemplo 7,30").setRequired(true))
    .addIntegerOption(o => o.setName("quantidade").setDescription("Unidades disponíveis").setRequired(true).setMinValue(0).setMaxValue(100000))
    .addStringOption(o => o.setName("descricao").setDescription("Descrição do produto").setRequired(true).setMaxLength(500)),
  new SlashCommandBuilder()
    .setName("estoque")
    .setDescription("Consulta o estoque atual"),
  new SlashCommandBuilder()
    .setName("pedido-pago")
    .setDescription("Confirma um pagamento após conferir o Pix no banco")
    .addIntegerOption(o => o.setName("pedido_id").setDescription("Número do pedido").setRequired(true).setMinValue(1)),
  new SlashCommandBuilder()
    .setName("pedido-cancelar")
    .setDescription("Cancela um pedido pendente")
    .addIntegerOption(o => o.setName("pedido_id").setDescription("Número do pedido").setRequired(true).setMinValue(1)),
  new SlashCommandBuilder()
    .setName("pedidos")
    .setDescription("Lista os pedidos recentes")
    .addIntegerOption(o => o.setName("quantidade").setDescription("Quantidade de pedidos (máximo 20)").setMinValue(1).setMaxValue(20))
].map(c => c.toJSON());

async function registerCommands() {
  const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
  await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), { body: commands });
  console.log("Comandos de barra registrados no servidor.");
}

function productEmbed(p) {
  return new EmbedBuilder()
    .setColor(0x2563eb)
    .setTitle(`🛍️ ${p.name}`)
    .setDescription(p.description)
    .addFields(
      { name: "Categoria", value: p.category, inline: true },
      { name: "Preço", value: money(p.price_cents), inline: true },
      { name: "Estoque", value: p.stock > 0 ? `${p.stock} disponível(is)` : "Esgotado", inline: true }
    )
    .setFooter({ text: "NEXUS SELECT • Qualidade e confiança" });
}

async function createOrder(interaction, product) {
  if (product.stock < 1) {
    return interaction.reply({ content: "❌ Esse produto está esgotado no momento.", ephemeral: true });
  }

  const guild = interaction.guild;
  const existing = db.prepare(
    "SELECT id FROM orders WHERE user_id = ? AND guild_id = ? AND status = 'pending'"
  ).get(interaction.user.id, guild.id);

  if (existing) {
    return interaction.reply({
      content: `Você já tem um pedido pendente (#${existing.id}). Termine esse atendimento primeiro.`,
      ephemeral: true
    });
  }

  const safeUser = interaction.user.username.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 16) || "cliente";
  const overwrites = [
    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
    { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.EmbedLinks] }
  ];
  if (process.env.ADMIN_ROLE_ID) {
    overwrites.push({
      id: process.env.ADMIN_ROLE_ID,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
    });
  }

  const channelOptions = {
    name: `pedido-${safeUser}-${Date.now().toString().slice(-4)}`,
    type: ChannelType.GuildText,
    permissionOverwrites: overwrites,
    topic: `Pedido em atendimento para ${interaction.user.tag}`
  };
  if (process.env.ORDER_CATEGORY_ID) channelOptions.parent = process.env.ORDER_CATEGORY_ID;

  let channel;
  try {
    channel = await guild.channels.create(channelOptions);
  } catch (err) {
    console.error("Falha ao criar canal do pedido:", err);
    return interaction.reply({ content: "Não consegui criar o canal privado. Confira as permissões do bot.", ephemeral: true });
  }

  let orderId;
  try {
    const reserve = db.transaction(() => {
      const changed = db.prepare(
        "UPDATE products SET stock = stock - 1 WHERE id = ? AND active = 1 AND stock > 0"
      ).run(product.id);
      if (changed.changes !== 1) throw new Error("Esse produto acabou de esgotar.");
      const result = db.prepare(`
        INSERT INTO orders (guild_id, channel_id, user_id, product_id, product_name, price_cents, status)
        VALUES (?, ?, ?, ?, ?, ?, 'pending')
      `).run(guild.id, channel.id, interaction.user.id, product.id, product.name, product.price_cents);
      return Number(result.lastInsertRowid);
    });
    orderId = reserve();
  } catch (err) {
    await channel.delete("Não foi possível reservar o produto").catch(() => {});
    return interaction.reply({ content: `❌ ${err.message}`, ephemeral: true });
  }

  const pixKey = process.env.PIX_KEY || "A equipe precisa configurar a chave Pix no arquivo .env";
  const pixName = process.env.PIX_NAME || "Nexus Select";
  const instructions = process.env.PIX_INSTRUCTIONS || "Faça o Pix e envie o comprovante neste canal. Aguarde a confirmação da equipe.";

  const embed = new EmbedBuilder()
    .setColor(0xf59e0b)
    .setTitle(`🧾 Pedido #${orderId} — aguardando pagamento`)
    .setDescription(`Olá, ${interaction.user}! Seu pedido foi criado. A equipe confirmará o pagamento após conferir o recebimento real.`)
    .addFields(
      { name: "Produto", value: product.name, inline: true },
      { name: "Valor", value: money(product.price_cents), inline: true },
      { name: "Chave Pix", value: `\`${pixKey}\`` },
      { name: "Recebedor informado", value: pixName },
      { name: "Instruções", value: instructions }
    )
    .setFooter({ text: "Não envie senhas ou códigos de acesso neste canal." });

  await channel.send({ content: `<@${interaction.user.id}> <@&${process.env.ADMIN_ROLE_ID}>`, embeds: [embed] });
  await interaction.reply({ content: `✅ Pedido #${orderId} criado: ${channel}`, ephemeral: true });

  const logId = process.env.LOG_CHANNEL_ID;
  if (logId) {
    const logChannel = await guild.channels.fetch(logId).catch(() => null);
    if (logChannel?.isTextBased()) {
      await logChannel.send(`🧾 Pedido **#${orderId}** aberto por ${interaction.user.tag}: **${product.name}** — ${money(product.price_cents)}.`);
    }
  }
}

client.once("ready", async () => {
  console.log(`Bot conectado como ${client.user.tag}`);
  try {
    await registerCommands();
  } catch (err) {
    console.error("Erro ao registrar comandos:", err);
  }
});

client.on("interactionCreate", async interaction => {
  try {
    if (interaction.isButton()) {
      if (!interaction.customId.startsWith("buy:")) return;
      const productId = Number(interaction.customId.split(":")[1]);
      const product = db.prepare("SELECT * FROM products WHERE id = ? AND active = 1").get(productId);
      if (!product) return interaction.reply({ content: "Esse produto não está mais disponível.", ephemeral: true });
      return createOrder(interaction, product);
    }

    if (!interaction.isChatInputCommand()) return;
    const { commandName } = interaction;

    if (["produto-adicionar", "estoque", "pedido-pago", "pedido-cancelar", "pedidos"].includes(commandName) && !isAdmin(interaction)) {
      return interaction.reply({ content: "⛔ Apenas a equipe autorizada pode usar esse comando.", ephemeral: true });
    }

    if (commandName === "loja") {
      const products = db.prepare("SELECT * FROM products WHERE active = 1 ORDER BY category, id").all();
      if (!products.length) {
        return interaction.reply({ content: "A loja ainda não tem produtos cadastrados. A equipe pode usar `/produto-adicionar`.", ephemeral: true });
      }
      await interaction.reply({ content: "🛍️ Catálogo da **NEXUS SELECT** publicado abaixo:" });
      for (const p of products.slice(0, 25)) {
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`buy:${p.id}`)
            .setLabel(p.stock > 0 ? "Comprar" : "Esgotado")
            .setStyle(p.stock > 0 ? ButtonStyle.Success : ButtonStyle.Secondary)
            .setDisabled(p.stock < 1)
        );
        await interaction.channel.send({ embeds: [productEmbed(p)], components: [row] });
      }
    }

    if (commandName === "produto-adicionar") {
      const name = interaction.options.getString("nome", true).trim();
      const category = interaction.options.getString("categoria", true);
      const price = parsePrice(interaction.options.getString("preco", true));
      const stock = interaction.options.getInteger("quantidade", true);
      const description = interaction.options.getString("descricao", true).trim();
      if (price === null) return interaction.reply({ content: "Preço inválido. Use, por exemplo, `7,30`.", ephemeral: true });

      const existing = db.prepare("SELECT * FROM products WHERE name = ? COLLATE NOCASE AND category = ?").get(name, category);
      if (existing) {
        db.prepare("UPDATE products SET price_cents = ?, stock = stock + ?, description = ?, active = 1 WHERE id = ?")
          .run(price, stock, description, existing.id);
        return interaction.reply({ content: `✅ Produto **${name}** atualizado. Foram adicionadas ${stock} unidade(s) ao estoque.`, ephemeral: true });
      }
      db.prepare("INSERT INTO products (name, category, description, price_cents, stock) VALUES (?, ?, ?, ?, ?)")
        .run(name, category, description, price, stock);
      return interaction.reply({ content: `✅ Produto **${name}** cadastrado por ${money(price)}, com ${stock} unidade(s) em estoque.`, ephemeral: true });
    }

    if (commandName === "estoque") {
      const products = db.prepare("SELECT id, name, category, price_cents, stock FROM products WHERE active = 1 ORDER BY category, name").all();
      if (!products.length) return interaction.reply({ content: "Nenhum produto cadastrado.", ephemeral: true });
      const lines = products.map(p => `**#${p.id} ${p.name}** — ${p.category} — ${money(p.price_cents)} — estoque: **${p.stock}**`);
      return interaction.reply({ content: lines.join("\n").slice(0, 1900), ephemeral: true });
    }

    if (commandName === "pedido-pago") {
      const id = interaction.options.getInteger("pedido_id", true);
      const order = db.prepare("SELECT * FROM orders WHERE id = ? AND guild_id = ?").get(id, interaction.guildId);
      if (!order) return interaction.reply({ content: "Pedido não encontrado.", ephemeral: true });
      if (order.status !== "pending") return interaction.reply({ content: `O pedido #${id} já está com status **${order.status}**.`, ephemeral: true });

      db.prepare("UPDATE orders SET status = 'paid', completed_at = CURRENT_TIMESTAMP WHERE id = ?").run(id);

      await interaction.reply({ content: `✅ Pedido #${id} marcado como pago. O estoque já havia sido reservado ao abrir o pedido. Confirme que o Pix foi recebido no banco antes de usar este comando.`, ephemeral: true });
      const channel = await interaction.guild.channels.fetch(order.channel_id).catch(() => null);
      if (channel?.isTextBased()) await channel.send(`✅ <@${order.user_id}> Pagamento do pedido **#${id}** confirmado pela equipe! A equipe seguirá com a entrega do produto.`);
      return;
    }

    if (commandName === "pedido-cancelar") {
      const id = interaction.options.getInteger("pedido_id", true);
      const order = db.prepare("SELECT * FROM orders WHERE id = ? AND guild_id = ?").get(id, interaction.guildId);
      if (!order) return interaction.reply({ content: "Pedido não encontrado.", ephemeral: true });
      if (order.status !== "pending") return interaction.reply({ content: `Só é possível cancelar pedidos pendentes. Status atual: ${order.status}.`, ephemeral: true });
      const cancelOrder = db.transaction(() => {
        db.prepare("UPDATE orders SET status = 'cancelled', completed_at = CURRENT_TIMESTAMP WHERE id = ?").run(id);
        db.prepare("UPDATE products SET stock = stock + 1 WHERE id = ?").run(order.product_id);
      });
      cancelOrder();
      await interaction.reply({ content: `🗑️ Pedido #${id} cancelado. A unidade reservada voltou ao estoque.`, ephemeral: true });
      const channel = await interaction.guild.channels.fetch(order.channel_id).catch(() => null);
      if (channel?.isTextBased()) await channel.send(`Pedido **#${id}** cancelado pela equipe. Se você já pagou, fale com um administrador antes de realizar outro pedido.`);
      return;
    }

    if (commandName === "pedidos") {
      const limit = interaction.options.getInteger("quantidade") || 10;
      const orders = db.prepare("SELECT id, user_id, product_name, price_cents, status, created_at FROM orders WHERE guild_id = ? ORDER BY id DESC LIMIT ?")
        .all(interaction.guildId, limit);
      if (!orders.length) return interaction.reply({ content: "Nenhum pedido registrado.", ephemeral: true });
      const lines = orders.map(o => `**#${o.id}** • <@${o.user_id}> • ${o.product_name} • ${money(o.price_cents)} • **${o.status}** • ${o.created_at}`);
      return interaction.reply({ content: lines.join("\n").slice(0, 1900), ephemeral: true });
    }
  } catch (err) {
    console.error("Erro ao processar interação:", err);
    const response = { content: "Ocorreu um erro. Confira o console do bot ou peça ajuda à equipe.", ephemeral: true };
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp(response).catch(() => {});
    } else {
      await interaction.reply(response).catch(() => {});
    }
  }
});

client.login(process.env.DISCORD_TOKEN);
